import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import News from "./components/News";
import Contact from './components/Contact';
import Account from './components/Account';
import Submitnews from './components/Submitnews';
import Loginerror from './components/Loginerror';
import { useState } from 'react';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  return (
    <>
    <Router>
    <div>
    <Navbar isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated} />
      <Routes>
      <Route path="/" element={<Home Newses = {News} isAuthenticated={isAuthenticated}/>} />
      <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
      <Route path="/register" element={<Register />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/account" element={<Account/>} />
      {isAuthenticated ? (
        <Route path="/submitnews" element={<Submitnews />} />
      ) : (
        <Route path="/loginerror" element={<Loginerror />} />
      )}
      </Routes>
      {/* <Background /> */}
      <Footer/>
      </div>
    </Router>
    </>
  );
}

export default App;
