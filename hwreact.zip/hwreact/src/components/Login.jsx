import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

// const Login = ({ setIsAuthenticated }) => {
//   // useNavigate used here
//   const navigate = useNavigate();

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     setIsAuthenticated(true);
//     navigate('/'); // redirect user to home page
//   };

//   return (
//     <div style={{
//       display: 'flex',
//       justifyContent: 'center',
//       alignItems: 'center',
//       height: '100vh',
//     }}>
//       <div style={{
//         background: '#fff',
//         padding: '20px',
//         borderRadius: '5px',
//         boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.2)',
//         width: '400px'
//       }}>
//         <h2 style={{
//           textAlign: 'center',
//           color: '#2b6e3b',
//         }}>Login Here</h2>
//         <form onSubmit={handleSubmit}>
//           <div style={{
//             marginBottom: '10px',
//           }}>
//             <label htmlFor="email" style={{
//               display: 'block',
//               fontSize: '14px',
//               fontWeight: 'bold',
//               color: '#2b6e3b',
//               marginBottom: '5px',
//             }}>Email:</label>
//             <input type="email" id="email" name="email" style={{
//               width: '370px',
//               padding: '10px',
//               borderRadius: '5px',
//               border: '1px solid #ddd',
//               fontSize: '16px',
//             }} />
//           </div>
//           <div style={{
//             marginBottom: '20px',
//           }}>
//             <label htmlFor="password" style={{
//               display: 'block',
//               fontSize: '14px',
//               fontWeight: 'bold',
//               color: '#2b6e3b',
//               marginBottom: '5px',
//             }}>Password:</label>
//             <input type="password" id="password" name="password" style={{
//               width: '370px',
//               padding: '10px',
//               borderRadius: '5px',
//               border: '1px solid #ddd',
//               fontSize: '16px',
//             }} />
//           </div>
//           <div style={{
//             textAlign: 'center',
//           }}>
//             <button type="submit" style={{
//               background: '#2b6e3b',
//               color: '#fff',
//               padding: '10px 20px',
//               borderRadius: '5px',
//               border: 'none',
//               fontSize: '16px',
//               cursor: 'pointer',
//             }}>Login</button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// }

// export default Login;
const Login = ({ setIsAuthenticated }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = (event) => {
    event.preventDefault();

    if (email === 'normaluser@example.com' && password === 'password12') {
      event.preventDefault();
      setIsAuthenticated(true)
      navigate('/');
    } else if (email === 'admin@example.com' && password === 'password123') {
      event.preventDefault();
      setIsAuthenticated(true)
      navigate('/admin');
    } else {
      alert('Invalid email or password');
    }
  };

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
    }}>
      <div style={{
        background: '#fff',
        padding: '20px',
        borderRadius: '5px',
        boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.2)',
        width: '400px'
      }}>
        <h2 style={{
          textAlign: 'center',
          color: '#2b6e3b',
        }}>Login Here</h2>
        <form onSubmit={handleLogin}>
          <div style={{
            marginBottom: '10px',
          }}>
            <label htmlFor="email" style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: 'bold',
              color: '#2b6e3b',
              marginBottom: '5px',
            }}>Email:</label>
            <input type="email" id="email" name="email" value={email} onChange={(event) => setEmail(event.target.value)} style={{
              width: '370px',
              padding: '10px',
              borderRadius: '5px',
              border: '1px solid #ddd',
              fontSize: '16px',
            }} />
          </div>
          <div style={{
            marginBottom: '20px',
          }}>
            <label htmlFor="password" style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: 'bold',
              color: '#2b6e3b',
              marginBottom: '5px',
            }}>Password:</label>
            <input type="password" id="password" name="password" value={password} onChange={(event) => setPassword(event.target.value)} style={{
              width: '370px',
              padding: '10px',
              borderRadius: '5px',
              border: '1px solid #ddd',
              fontSize: '16px',
            }} />
          </div>
          <div style={{
            textAlign: 'center',
          }}>
            <button type="submit" style={{
              background: '#2b6e3b',
              color: '#fff',
              padding: '10px 20px',
              borderRadius: '5px',
              border: 'none',
              fontSize: '16px',
              cursor: 'pointer',
            }}>Login</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Login;