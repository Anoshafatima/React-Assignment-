import React from 'react'
import { useState } from "react";

const Submitnews = () => {
  const [title, setTitle] = useState("");
  const [news, setNews] = useState("");
  const [category, setCategory] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle the submission of the news
    console.log("Title:", title);
    console.log("News:", news);
    console.log("Category:", category);
  };


  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
    }}>
      <div className="container" style={{ maxWidth: '500px', width: '100%' }}>
        <h2>Submit News</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group" style={{ marginBottom: '20px' }}>
            <label htmlFor="title" style={{ display: 'block', marginBottom: '5px' }}>Title:</label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              style={{ width: '100%', padding: '10px', fontSize: '16px', border: '1px solid #ddd', borderRadius: '5px' }}
            />
          </div>

          <div className="form-group" style={{ marginBottom: '20px' }}>
            <label htmlFor="news" style={{ display: 'block', marginBottom: '5px' }}>News:</label>
            <textarea
              id="news"
              value={news}
              onChange={(event) => setNews(event.target.value)}
              style={{ width: '100%', padding: '10px', fontSize: '16px', border: '1px solid #ddd', borderRadius: '5px' }}
            ></textarea>
          </div>

          <div className="form-group" style={{ marginBottom: '20px' }}>
            <label htmlFor="category" style={{ display: 'block', marginBottom: '5px' }}>Category:</label>
            <select
              id="category"
              value={category}
              onChange={(event) => setCategory(event.target.value)}
              style={{ width: '100%', padding: '10px', fontSize: '16px', border: '1px solid #ddd', borderRadius: '5px' }}
            >
              <option value="">Select a category</option>
              <option value="politics">Politics</option>
              <option value="entertainment">Entertainment</option>
              <option value="technology">Technology</option>
              <option value="sports">Sports</option>
            </select>
          </div>

          <button type="submit" style={{ padding: '10px 20px', fontSize: '16px', background: 'green', color: '#fff', border: 'none', borderRadius: '5px' }}>Submit</button>
        </form>
      </div>
    </div>
  );
}

export default Submitnews;