import React, { useState, useEffect } from 'react';

const Contact = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    if (name && email && message) {
      // Form data is valid, so submit it
      submitForm();
    }
  }, [name, email, message]);

  const submitForm = () => {
    // Here you would make an API request to submit the form data
    console.log(`Name: ${name}, Email: ${email}, Message: ${message}`);
    setIsSubmitted(true);
  }

  const handleSubmit = (event) => {
    event.preventDefault();

    // Validate form data
    let errors = {};
    if (!name) {
      errors.name = 'Name is required';
    }
    if (!email) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Invalid email address';
    }
    if (!message) {
      errors.message = 'Message is required';
    }

    // Update state with any validation errors
    setErrors(errors);
  }

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
    }}>
      <div style={{
        background: '#fff',
        padding: '20px',
        borderRadius: '5px',
        boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.2)',
        width: '400px'
      }}>
        <h2 style={{
          textAlign: 'center',
          color: '#2b6e3b',
        }}>Contact Us</h2>
        {isSubmitted && <div style={{ color: 'green', marginBottom: '10px' }}>Information received successfully!</div>}
        <form onSubmit={handleSubmit}>
          <div style={{
            marginBottom: '10px',
          }}>
            <label htmlFor="name" style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: 'bold',
              color: '#2b6e3b',
              marginBottom: '5px',
            }}>Name:</label>
            <input type="text" id="name" name="name" value={name} onChange={(event) => setName(event.target.value)} style={{
              width: '370px',
              padding: '10px',
              borderRadius: '5px',
              border: '1px solid #ddd',
              fontSize: '16px',
            }} />
            {errors.name && <div style={{ color: 'red' }}>{errors.name}</div>}
          </div>
          <div style={{
            marginBottom: '20px',
          }}>
            <label htmlFor="email" style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: 'bold',
              color: '#2b6e3b',
              marginBottom: '5px',
            }}>Email:</label>
            <input type="email" id="email" name="email" value={email} onChange={(event) => setEmail(event.target.value)} style ={{
            width: '370px',
            padding: '10px',
            borderRadius: '5px',
            border: '1px solid #ddd',
            fontSize: '16px',
            }} />
            {errors.email && <div style={{ color: 'red' }}>{errors.email}</div>}
            </div>
            <div style={{
            marginBottom: '20px',
            }}>
            <label htmlFor="message" style={{
            display: 'block',
            fontSize: '14px',
            fontWeight: 'bold',
            color: '#2b6e3b',
            marginBottom: '5px',
            }}>Message:</label>
            <textarea id="message" name="message" value={message} onChange={(event) => setMessage(event.target.value)} style={{
            width: '370px',
            height: '150px',
            padding: '10px',
            borderRadius: '5px',
            border: '1px solid #ddd',
            fontSize: '16px',
            }}></textarea>
            {errors.message && <div style={{ color: 'red' }}>{errors.message}</div>}
            </div>
            <button type="submit" style={{
            background: '#2b6e3b',
            color: '#fff',
            padding: '10px',
            borderRadius: '5px',
            border: 'none',
            fontSize: '16px',
            cursor: 'pointer',
            }}>Submit</button>
            </form>
            </div>
            </div>
            );
            }

            export default Contact;
