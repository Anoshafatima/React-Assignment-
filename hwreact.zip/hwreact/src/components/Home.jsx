// import React, { useState } from 'react';
import React, { useState } from 'react';
import './News.css';
import { useNavigate } from 'react-router-dom';

const Home = ({ Newses, isAuthenticated }) => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('All');

  const handleNewsSubmit = (event) => {
    event.preventDefault();
    if (isAuthenticated) {
      navigate('/submitnews');
    } else {
      navigate('/loginerror');
    }
  };

  const handleCategoryChange = (event) => {
    setSelectedCategory(event.target.value);
  };

  const filteredNewses = selectedCategory === 'All'
    ? Newses
    : Newses.filter((news) => news.category === selectedCategory);

  return (
    <div className="news-container">
      <form>
        <h1 style={{ color: 'green', textAlign: 'center' }}>HU NEWS WEB</h1>
        <br />
        <p style={{ textAlign: 'center' }}>
          Welcome to HU News Bulletin. If you wish to report your news, login with your account and submit your news. If you
          are a new user you can register to our website. You can also read through news as a guest user.
        </p>
        <br />
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <button
            type="submit"
            onClick={handleNewsSubmit}
            style={{
              background: '#2b6e3b',
              color: '#fff',
              padding: '10px 20px',
              borderRadius: '5px',
              border: 'none',
              fontSize: '16px',
              cursor: 'pointer',
            }}
          >
            Submit News
          </button>
        </div>
        <br />
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <label htmlFor="category-select" style={{ marginRight: '10px' }}>Select category:</label>
          <select id="category-select" value={selectedCategory} onChange={handleCategoryChange}>
            <option value="All">All</option>
            <option value="Politics">Politics</option>
            <option value="Technology">Technology</option>
            <option value="Sports">Sports</option>
          </select>
        </div>
      </form>
      {filteredNewses.map((news) => (
        <div className="news-item" key={news.newstitle}>
          <h2 className="news-title">
            <b>Title: </b>
            {news.newstitle}
          </h2>
          <p className="news-text">
            <b>News: </b>
            {news.news}
          </p>
          <div className="news-meta">
            <span className="news-category">
              <b>Category: </b>
              {news.category}
            </span>
            <br />
            <span className="news-date">
              <b>Publishing Date: </b>
              {news.date}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Home;

