import React, { useState } from 'react';

const Account = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');

  const handleUpdateDetails = (event) => {
    event.preventDefault();
    alert('Details Successfully Updated');
  };

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
    }}>
      <div style={{
        background: '#fff',
        padding: '20px',
        borderRadius: '5px',
        boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.2)',
        width: '400px'
      }}>
        <h2 style={{
          textAlign: 'center',
          color: '#2b6e3b',
        }}>Update Account Details</h2>
        <form onSubmit={handleUpdateDetails}>
          <div style={{
            marginBottom: '10px',
          }}>
            <label htmlFor="username" style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: 'bold',
              color: '#2b6e3b',
              marginBottom: '5px',
            }}>Username:</label>
            <input type="text" id="username" name="username" value={username} onChange={(event) => setUsername(event.target.value)} style={{
              width: '370px',
              padding: '10px',
              borderRadius: '5px',
              border: '1px solid #ddd',
              fontSize: '16px',
            }} />
          </div>
          <div style={{
            marginBottom: '20px',
          }}>
            <label htmlFor="email" style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: 'bold',
              color: '#2b6e3b',
              marginBottom: '5px',
            }}>Email:</label>
            <input type="email" id="email" name="email" value={email} onChange={(event) => setEmail(event.target.value)} style={{
              width: '370px',
              padding: '10px',
              borderRadius: '5px',
              border: '1px solid #ddd',
              fontSize: '16px',
            }} />
          </div>
          <div style={{
            textAlign: 'center',
          }}>
            <button type="submit" style={{
              background: '#2b6e3b',
              color: '#fff',
              padding: '10px 20px',
              borderRadius: '5px',
              border: 'none',
              fontSize: '16px',
              cursor: 'pointer',
            }}>Update Details</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Account;
