import React from 'react'
import "./Footer.css";
const Footer = () => {
  return (
    <footer className="footer">
    <div className="footer-container">
      <h2 className="footer-title">HU NEWS WEB | 2023</h2>
    </div>
  </footer>
  );
}

export default Footer
