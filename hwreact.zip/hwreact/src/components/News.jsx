export const Newses = [
    
    {newstitle: "US 'sorry' Pakistan skipped democracy summit, but says country 'can make its own decisions'", 
    news: "Pakistan’s decision not to participate in the second Summit for Democracy, hosted by the United States, does not change the Biden administration’s willingness to continue to work with Islamabad on a “broad range of issues,” a State Department spokesperson said. At the same time, spokesperson Vedant Patel said the US was “certainly sorry that Pakistan chose not to participate” in the three-day event that ended Thursday after discussing topics like strengthening democracy and defending against authoritarianism, addressing and fighting corruption, and promoting respect for human rights.", 
    category: "Politics", 
    date: "March 31, 2023"},
    {newstitle: "Google: India tribunal upholds $160m fine on company", 
    news: "An Indian appeals court has upheld a $160m fine imposed on Google by the country's antitrust regulator in a case related to Android's market dominance. The National Company Law Appellate Tribunal (NCLAT) said the Competition Commission of India (CCI) findings were correct and Google was liable to pay the fine. But it set aside four of 10 antitrust directives imposed on the firm. More than 95% of Indian smartphones use the Android system. In October, the CCI accused Google of exploiting its dominant position and imposed the fine for 'unfair' business practices. It also asked Google to make several changes to the Android ecosystem. This included not forcing manufacturers to pre-install the entire suite of Google apps and allowing users to choose their default search engine. The Android-related inquiry was started in 2019, following complaints by consumers of Android smartphones. The case was similar to the one Google faced in Europe, where regulators imposed a $5bn fine on the company, saying it used its Android operating system to gain unfair advantage in the market. Google challenged the fine and the directives in India's Supreme Court, saying no other jurisdiction has ever asked for such far-reaching changes. It argued that the changes would force the company to alter arrangements with more than 1,100 device manufacturers and thousands of app developers.", 
    category: "Technology", 
    date: "March 31, 2023"},
    {newstitle: "Sri Lanka unable to automatically qualify for World Cup after New Zealand defeat", 
    news: "Sri Lanka will have to go through a qualifying stage to reach October's 50-over World Cup after a six-wicket defeat by New Zealand in Hamilton. The 1996 champions, who have featured in every 50-over World Cup, are now unable to qualify automatically. They were bowled out for 157 after opting to bat, with Pathum Nissanka making 57 and Dasun Shanaka 31. New Zealand were 59-4 but Will Young (86*) and Henry Nicholls (40*) shared an unbroken 100 to see the hosts home. Matt Henry took 3-14 for the Kiwis as Sri Lanka were reduced to 18-3 before all-rounder Daryl Mitchell and fast bowler Henry Shipley both claimed 3-32. The win sees New Zealand take the three-match series 2-0 after a 198-run win in the first game before a washout in the second.", 
    category: "Sports", 
    date: "March 31, 2023"},
    
      

]

export default Newses;